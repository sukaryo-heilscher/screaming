
/* 
 * A function that executes a command using fork and execv
 */
void execute_plain(char *cmd, char *const argv[]) {
  if (!fork()) { //child's code
    int ex = execv(cmd, argv);
    exit(ex);
  }
  int child_retVal;
  wait(&child_retVal);
  if (child_retVal != 0 ) {
    printf(" ** Command failed **\n");
  } else {
    printf(" ** Command successful **\n");
  }
}

/* 
 * A function that executes a command using fork and execv, but
 * that redirects the command's output to a file
 */
void execute_output_to_file(char *cmd, char *const argv[], char *filename) {
  if (!fork()) { //child's code
    close(1);
    FILE *file = fopen(filename, "w");
    int ex = execv(cmd, argv);
    fclose(file);
    exit(ex);
  }
  int child_retVal;
  wait(&child_retVal);
  if (child_retVal != 0 ) {
    printf(" ** Command failed **\n");
  } else {
    printf(" ** Command successful **\n");
  }
}

/* 
 * A function that executes a command using fork and execv, but
 * that redirects the command's output to another command
 */
void execute_output_to_other(char *cmd1, char *const argv1[], char *cmd2_with_argv2) {
  int fds[2];
  int p = pipe(fds);
  if (!fork()) {
    close(fds[0]);
    close(1); //close stdout
    dup(fds[1]);
    int ex = execv(cmd1, argv1);
    exit(ex);
  }
  int child_retVal;
  wait(&child_retVal);
  if (!fork()) { //child's code
    close(fds[1]);
    close(0); //close stdin
    dup(fds[0]);
    FILE *p = popen(cmd2_with_argv2, "w");
    int ex = pclose(p);
    exit(ex);
  }
  int child_retVal2;
  wait(&child_retVal2);
  if (child_retVal != 0 || child_retVal2 != 0 || p != 0) {
    printf(" ** Command failed **\n");
  } else {
    printf(" ** Command successful **\n");
  }

  /********failed code
  int fds[2];
  int p = pipe(fds);
  if (!fork()) { //write-end child's code
    close(fds[0]);
    close(1); //close stdout
    dup(fds[1]);
    int ex = execv(cmd1, argv1);
    exit(ex);
  }
  int child_retVal;
  wait(&child_retVal);

  if (!fork()) { //read-end child's code
    close(fds[1]);
    close(0); //close stdin
    dup(fds[0]);

    char *mycmd = NULL;
    char **mycmd_argv = {NULL};
    parse_cmd_string(cmd2_with_argv2, &mycmd, &mycmd_argv, NULL);
    int ex = execv(mycmd, mycmd_argv);
    exit(ex);
  }

  int child_retVal2;
  wait(&child_retVal2);
  if (p + child_retVal + child_retVal2 != 0 ) {
    printf(" ** Command failed **\n");
  } else {
    printf(" ** Command successful **\n");
  }*****************/
}


