
/* 
 * A function that executes a command using fork and execv
 */
void execute_plain(char *cmd, char *const argv[]) {
  fprintf(stdout,"Error: %s() is not implemented!\n\n", __FUNCTION__);

  // WRITE CODE HERE
  
}

/* 
 * A function that executes a command using fork and execv, but
 * that redirects the command's output to a file
 */
void execute_output_to_file(char *cmd, char *const argv[], char *filename) {
  fprintf(stdout,"Error: %s() is not implemented!\n\n", __FUNCTION__);

  // WRITE CODE HERE

}

/* 
 * A function that executes a command using fork and execv, but
 * that redirects the command's output to another command
 */
void execute_output_to_other(char *cmd1, char *const argv1[], char *cmd2_with_argv2) {
  fprintf(stdout,"Error: %s() is not implemented!\n\n", __FUNCTION__);

  // WRITE CODE HERE

}


